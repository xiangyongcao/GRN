%% Generate Training Dataset (Stage 1: iid Gaussian: sigma = 50)
rng(0)
addpath(genpath('lib'));

basedir = 'F:\desktop\GRSL-\TNNLS\QRNN3D-master\matlab\Data';
datadir = 'F:\desktop\GRSL-\TNNLS\QRNN3D-master\matlab\ori_data\';
g = load(fullfile(basedir, 'train_fns.mat'));
fns = g.fns;

for sigma = [50]
    newdir = fullfile(basedir, ['\Train','\','icvl_', num2str(sigma)]);
    generate_dataset(datadir, fns, newdir, sigma, 'rad');
end

