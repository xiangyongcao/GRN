%% read the all the filenames in a file

namelist = dir('F:\desktop\GRSL-\TNNLS\QRNN3D-master\matlab\ori_data\*.mat');

% ��ȡ��namelist �ĸ�ʽΪ
% name -- filename
% date -- modification date
% bytes -- number of bytes allocated to the file
% isdir -- 1 if name is a directory and 0 if not

len = length(namelist);
for i = 1:len
    fns{i} = namelist(i).name;
    fns = fns';
%     x = load(file_name{i});
end
save('F:\desktop\GRSL-\TNNLS\QRNN3D-master\matlab\Data\train_fns.mat','fns') 

