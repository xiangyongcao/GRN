%% Generate Training Dataset (Stage 2: iid Gaussian: sigma unknown and randomly selected from [10,70])
rng(0)
addpath(genpath('lib'));

basedir = 'F:\desktop\GRSL-\TNNLS\QRNN3D-master\matlab\Data';
datadir = 'F:\desktop\GRSL-\TNNLS\QRNN3D-master\matlab\ori_data\';
g = load(fullfile(basedir, 'train_fns.mat'));
fns = g.fns;

newdir = fullfile(basedir, ['\Train','\','icvl_','blind']);
generate_dataset_blind(datadir, fns, newdir, 'rad');


