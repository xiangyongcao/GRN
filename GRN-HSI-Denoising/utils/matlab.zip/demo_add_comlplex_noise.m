%% Generate Training Dataset (Stage 3: complex noise)
rng(0)
addpath(genpath('lib'));

basedir = 'F:\desktop\GRSL-\TNNLS\QRNN3D-master\matlab\Data';
datadir = 'F:\desktop\GRSL-\TNNLS\QRNN3D-master\matlab\ori_data\';
g = load(fullfile(basedir, 'train_fns.mat'));
fns = g.fns;

% %%% for complex noise (randomly select from case 1 to case 4)
newdir = fullfile(basedir, ['\Train','\','icvl_', 'complex']);
sigmas = [10 30 50 70];
generate_dataset_mixture_train(datadir, fns, newdir, sigmas, 'rad');
